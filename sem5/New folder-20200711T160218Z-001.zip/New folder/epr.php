<html>
<head>
	<meta charset="utf-8">
	<title> 4S Hospital </title>
	
	<link href="style.css" type="text/css" rel="stylesheet">
	
</head>
<style type="text/css">
		.l1{
		color: white;
		padding: 2px;
		width:100px;
		height:30px;
		background-color: lightblue;
		border-bottom:orange solid 3px;
		float: left;
		margin:15px;
		padding: 5px;
		margin-left: 150px;
		border-radius: 15px;
		}
		.l1:hover{
		background-color: #0cfcf8;
		}
		#eprleft{
			top:300px;
		}
		.body{
			height:0px;
			position: fixed;
		}
		.nav_down{
	width:100%;
	background-color:#2FA5EB !important;
	border-bottom:2px solid #f0f0f0;
}
.nav_down div{
	width:1200px;
	color:#fff;
	background-color:#000;
	font-family:calibri;
	padding:10px;
	text-align:left;
	margin-top: 300px;
}
.b{
	width:180px;
	height: 35px;
	left: 500px;
	top: 420px;
	background: green;
	position: absolute;
	color: white;
	font-size: 20px;
	border-radius: 5px/5px;
	cursor: pointer;
	outline: none;
}

	
</style>
<body>
	
	<div class="top">
		<div>
		
		</div>
	</div>
	
<header>
	<div id="logo">4S-SUVARNA SUPRIYA SHARANYA SAKSHI</div>
</header>
	
	
	
	<div id="blur">
		
		<div id="eprleft">
			<ul type="none" class="h1">
			<br>
			<br>
			<br>
			<br>
			<h1>UPDATE:</h1>
					<li class="l1" ><a href="p.php">Patient</a></li>
					<li class="l1" ><a href="d.php">Doctor</a></li>
					<li class="l1"><a href="b.php">Bill	</a></li>
					<li class="l1"><a href="m.php">Medicine	</a></li><br><br><br>
			<h1>VIEW:</h1>
					<li class="l1"><a href="billgen.php">BILL GENERATION</a></li>
					<li class="l1"><a href="td.php">TOTAL DOCTORS</a></li><br>
			<button name="Sign_Up" value="Log Out" class="b"><a href="main.php">Log Out</a></button>   
        
			</ul>
		</div>
	</div>
	<div class="nav_down">
		<div>
		 &copy; 4S HospitaL, THANE-WEST 
		</div>
	</div>
	
</body>
</html>