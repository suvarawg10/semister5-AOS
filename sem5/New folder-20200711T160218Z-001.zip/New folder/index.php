<html>
<head>
	<title> 4S Hospital </title>
	
	<link href="css/style.css" type="text/css" rel="stylesheet">
	
</head>
<body>
	
	<div class="top">
		<div>
		 Contact Us +91 9967571224 / +0251-244 3646 | 4S@hospital.
		 |<a href="main.php">epr</a> 

		</div>
	</div>
	
	<div class="logo">
		<div>
			<table>
				<tr>
					<td width="600px" style="font-size:50px;font-family:forte;"> <font color="#428bca"> 4S  </font><font color="#000"> Hospital</font> </td>
					<td> <br> <br>
						<font size="4px"> 
							<a href="index.php">HOME</a> 
							<a href="about.php">ABOUT US</a>  
							<a href="service.php">SERVICE</a>
							<a href="doctor.php">DOCTORS</a> 
							<a href="contact.php">CONTACT US</a>
						</font>
					</td>
				</tr>
			</table>
		</div>
	</div>
	
	<div class="middle">
		<div style="background-image:url('img/a.jpg');">
		<p>
			<br> <br>
					Health Care Services  <br>
			<font size="5px"> We Care About Your Health </font>
		</p> 
		</div>
	</div>
	
	<div class="bottom">
		<div>
			<table border="0">
				<tr>
					<td width="700px">
						<font color="#000"> We are medical center </font> <br> <br>

					<font color="#000" size="5px"> We Have Medicare Plan Options for You! </font> <br> <br>

          4S Hospital & Health Care Centre was established in September 2009. A leading integrated Health Care Institution providing world class health care services for the Population, Elite & and Common people. It has a large network of integrated health care services with world class diagnostic equipments, medical facilities and latest technology in Neurosurgery, General Surgery, Orthopedic Surgery, Maxillo-Facial Surgery, Psychiatry, Medicine Department, Physiotherapy, Critical Care Department, Dental Treatments and Psychotherapy etc. <br><br>

4S Hospital is registered under ISO-9001. The hospital is Fully Air-Conditioned with a total capacity of 50 beds & more than 100 Staff are working here with a great propensity for Patient Care.<br><br>
<ul>
<br>
	
	
	
	
	<div class="nav_down">
		<div>
		 &copy; 4S Hospital, THANE-WEST. 
		</div>
	</div>
</body>
</html>
